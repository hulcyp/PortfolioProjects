#pragma once

#include <string>
#include <vector>

namespace pdh
{
	void stringTokenizer( const std::string& s, std::vector< std::string >& tokens, const std::string& pattern = " " );
}
