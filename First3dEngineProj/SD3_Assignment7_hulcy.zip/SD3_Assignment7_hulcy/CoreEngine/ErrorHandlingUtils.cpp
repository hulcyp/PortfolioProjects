#include "ErrorHandlingUtils.h"
#include <windows.h>
#ifdef _WIN32
#include <glew.h>
#endif
#include <glut.h>
#include <map>

namespace pdh
{
	void reportError( const char* title, const char* msg )
	{
		MessageBoxA( NULL, msg, title, MB_OK | MB_ICONERROR | MB_SETFOREGROUND );
	}
	void fatalError( const char* title, const char* msg )
	{
		MessageBoxA( NULL, msg, title, MB_OK | MB_ICONERROR | MB_SETFOREGROUND );
		exit( -1 );
	}

	void printErrorToOutputConsole( const char* error )
	{
		OutputDebugStringA( error );
	}

	std::string& getGlErrorAsString()
	{
		static bool init = false;
		static std::map< int, std::string > glErrorStrings;
		if( !init )
		{
			glErrorStrings[ GL_NO_ERROR ] = "GL_NO_ERROR";
			glErrorStrings[ GL_INVALID_ENUM ] = "GL_INVALID_ENUM";
			glErrorStrings[ GL_INVALID_VALUE ] = "GL_INVALID_VALUE";
			glErrorStrings[ GL_INVALID_OPERATION ] = "GL_INVALID_OPERATION";
			glErrorStrings[ GL_INVALID_FRAMEBUFFER_OPERATION ]  = "GL_INVALID_FRAMEBUFFER_OPERATION";
			glErrorStrings[ GL_OUT_OF_MEMORY ] = "GL_OUT_OF_MEMORY";
			glErrorStrings[ GL_STACK_UNDERFLOW ] = "GL_STACK_UNDERFLOW";
			glErrorStrings[ GL_STACK_OVERFLOW ] = "GL_STACK_OVERFLOW";
			init = true;
		}

		return std::string( "Open GL Error: " ).append( glErrorStrings[ glGetError() ] );
	}
}