#include "StringUtils.h"
#include <algorithm>

namespace pdh
{
	void stringToLowerCase( std::string& text )
	{
		std::transform( text.begin(), text.end(), text.begin(), ::tolower );
	}
}