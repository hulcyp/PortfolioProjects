#pragma once


namespace pdh
{
	template< typename T >
	class Ray
	{
	
	};
}