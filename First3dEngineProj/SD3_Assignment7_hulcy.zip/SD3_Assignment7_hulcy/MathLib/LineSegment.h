#pragma once

namespace pdh
{
	template< typename T >
	class LineSegment
	{
		
	};
}